package com.example.lembretedemedicamentos.ui.adapter;

//public class MedicationAdapter {
//}

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lembretedemedicamentos.R;
import com.example.lembretedemedicamentos.data.Medication;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MedicationAdapter extends RecyclerView.Adapter<MedicationAdapter.MedicationViewHolder> {

    private List<Medication> medications = new ArrayList<>();

    @NonNull
    @Override
    public MedicationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_medication, parent, false);
        return new MedicationViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MedicationViewHolder holder, int position) {
        Medication currentMedication = medications.get(position);
        holder.tvName.setText(currentMedication.name);
        holder.tvDosage.setText(currentMedication.dosage);
        // Formata a hora e o minuto para o formato HH:mm
        String time = String.format(Locale.getDefault(), "%02d:%02d", currentMedication.hour, currentMedication.minute);
        holder.tvTime.setText(time);
    }

    @Override
    public int getItemCount() {
        return medications.size();
    }

    public void setMedications(List<Medication> medications) {
        this.medications = medications;
        notifyDataSetChanged(); // Notifica o RecyclerView que os dados mudaram
    }

    static class MedicationViewHolder extends RecyclerView.ViewHolder {
        private final TextView tvName;
        private final TextView tvDosage;
        private final TextView tvTime;

        public MedicationViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_medication_name);
            tvDosage = itemView.findViewById(R.id.tv_medication_dosage);
            tvTime = itemView.findViewById(R.id.tv_medication_time);
        }
    }
}